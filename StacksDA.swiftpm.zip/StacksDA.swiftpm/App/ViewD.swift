import SwiftUI

struct ViewD: View {
    var body: some View {
        
       
        VStack(alignment: .leading) {
           
            HStack {
               
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    Text("🍔")
                        .font(.system(size: 50))
                }
                Text("📒")
                    .font(.system(size: 100))
                    .padding(50)
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    Text("🍔")
                        .font(.system(size: 50))
                }
            }
            
           
            HStack {
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
            }            
            HStack {
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                Text("📒")
                    .font(.system(size: 100))
                    .padding(50)
                
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                   
                }
            }
        }
    }
}


struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}
