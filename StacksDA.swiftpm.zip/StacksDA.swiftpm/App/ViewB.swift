import SwiftUI

struct ViewB: View {
    var body: some View {
        /*#-code-walkthrough(HS.1)*/
        HStack {
            /*#-code-walkthrough(CV.1)*/
            Text("📒")
                .font(.system(size: 148))
            Text("🍔")
                .font(.system(size: 148))
            /*#-code-walkthrough(.1)*/
        }
        /*#-code-walkthrough(HS.1)*/
    }
}

struct ViewB_Previews: PreviewProvider {
    static var previews: some View {
        ViewB()
    }
}

