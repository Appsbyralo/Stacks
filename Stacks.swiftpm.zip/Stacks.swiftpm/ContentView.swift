/*
 HStack, VStack, and ZStack are ways to organize things on your screen in Swift. HStack arranges items side by side horizontally, VStack arranges them up and down vertically, and ZStack layers items on top of each other. To use them, you just put your items inside the stack you want in your SwiftUI code.
 
 */



import SwiftUI

struct ContentView: View {
    
    var body: some View {
       
        TabView {
            // The first tab shows VStackView with a VStack
            VStackView()
                .tabItem {
                    // Each tab has an icon and a text label
                    Image(systemName: "lines.measurement.vertical")
                    Text("VStack")
                }
            // The second tab shows HStackView with a HStack
            HStackView()
                .tabItem {
                    Image(systemName: "lines.measurement.horizontal")
                    Text("HStack")
                }
            // The third tab shows ZStackView with a ZStack
            ZStackView()
                .tabItem {
                    Image(systemName: "square.grid.3x1.below.line.grid.1x2")
                    Text("ZStack")
                }
            // The fourth tab shows VHZStackView with a combination of VStack, HStack, and ZStack
            VHZStackView()
                .tabItem {
                    Image(systemName: "pencil.and.outline")
                    Text("VHZStack")
                }
        }
    }
}

// This struct is used for previewing the ContentView
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

