/* 

 There are Children are the items inside a container view like VStack, HStack, or ZStack.
Here, the children of HStack are two Text views (the book and burger emojis).
Display a book emoji with a large font size. What would happen, if you had the image of the burger first and the image of the book underneath it in the code?
*/


import SwiftUI

// This struct is called HStackView. We use it to define a new view.
struct HStackView: View {
    var body: some View {
        // HStack arranges its children (the items inside it) in a horizontal line, from left to right.
        HStack {
            // Children are the items inside a container view like VStack, HStack, or ZStack.
            // Here, the children of HStack are two Text views (the book and burger emojis).
            // Display a book emoji with a large font size. What would happen, if you had the image of the burger first and the image of the book underneath it in the code?
            Text("📒")
                .font(.system(size: 148))
            // Display a burger emoji with a large font size
            Text("🍔")
                .font(.system(size: 148))
        }
    }
}

// This struct is used for previewing the HStackView.
// It helps you see what the HStackView will look like without running the full app.
struct HStackView_Previews: PreviewProvider {
    static var previews: some View {
        HStackView()
    }
}

