/* 
 Challenge:
Modify this code to place the burger emoji on the middle book icon in the middle row,
and on the first and third book icons in the third row.
To complete this challenge, you need to edit the ZStack views in the middle row and
the first and third ZStack views in the third row to include the burger emoji.
*/

import SwiftUI

struct VHZStackView: View {
    var body: some View {
       
        // VStack arranges its children (the items inside it) in a vertical line
        VStack(alignment: .leading) {
            // HStack arranges its children in a horizontal line
            HStack {
                // ZStack overlays its children on top of each other - First the book, then the burger on top of it. What would happen, if you had the image of the burger first and the image of the book underneath it in the code?
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    Text("🍔")
                        .font(.system(size: 50))
                }
                Text("📒")
                    .font(.system(size: 100))
                    .padding(50)
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    Text("🍔")
                        .font(.system(size: 50))
                }
            }
            
            // Second row of HStack. Where to put the burger?
            HStack {
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                Text("📒")
                    .font(.system(size: 100))
                    .padding(50)
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    
                }
            }
            
            // Third row of HStack. where to put the two burgers?
            HStack {
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                Text("📒")
                    .font(.system(size: 100))
                    .padding(50)
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
            }
        }
    }
}

// This struct is used for previewing the VHZStackView.
struct VHZStackView_Previews: PreviewProvider {
    static var previews: some View {
        VHZStackView()
    }
}

