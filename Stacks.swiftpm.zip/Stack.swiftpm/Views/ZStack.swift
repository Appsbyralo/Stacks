import SwiftUI

// This struct is called ZStackView. We use it to define a new view.
struct ZStackView: View {
    var body: some View {
        // ZStack overlays its children (the items inside it) on top of each other.
        ZStack {
            // Children are the items inside a container view like VStack, HStack, or ZStack.
            // Here, the children of ZStack are a Color view and two Text views (the book and burger emojis).
            // A background color
            Color(.blue)
            // Display a book emoji with a large font size
            Text("📒")
                .font(.system(size: 148))
            // Display a smaller burger emoji on top of the book emoji
            Text("🍔")
                .font(.system(size: 75))
        }
    }
}

// This struct is used for previewing the ZStackView.
// It helps you see what the ZStackView will look like without running the full app.
struct ZStackView_Previews: PreviewProvider {
    static var previews: some View {
        ZStackView()
    }
}

