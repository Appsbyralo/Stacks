import SwiftUI

// This struct is called VStackView. We use it to define a new view.
struct VStackView: View {
    var body: some View {
        // VStack arranges its children (the items inside it) in a vertical line, from top to bottom.
        VStack {
            // Children are the items inside a container view like VStack, HStack, or ZStack.
            // Here, the children of VStack are two Text views (the book and burger emojis).
            // Display a book emoji with a large font size
            Text("📒")
                .font(.system(size: 148))
            // Display a burger emoji with a large font size
            Text("🍔")
                .font(.system(size: 148))
        }
    }
}

// This struct is used for previewing the VStackView.
// It helps you see what the VStackView will look like without running the full app.
struct VStackView_Previews: PreviewProvider {
    static var previews: some View {
        VStackView()
    }
}

