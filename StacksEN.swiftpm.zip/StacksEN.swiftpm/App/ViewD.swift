import SwiftUI

struct ViewD: View {
    var body: some View {
        
        /*#-code-walkthrough(VHZ.1)*/
        /*#-code-walkthrough(VHZ.2)*/
        VStack(alignment: .leading) {
            /*#-code-walkthrough(VHZ.3)*/
            HStack {
                /*#-code-walkthrough(VHZ.4)*/
                ZStack {
                    /*#-code-walkthrough(VHZ.1)*/
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    Text("🍔")
                        .font(.system(size: 50))
                }
                /*#-code-walkthrough(VHZ.4)*/
                Text("📒")
                    .font(.system(size: 100))
                    .padding(50)
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    Text("🍔")
                        .font(.system(size: 50))
                }
            }
            
            /*#-code-walkthrough(VHZ.3)*/
            HStack {
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
            }            
            HStack {
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                }
                Text("📒")
                    .font(.system(size: 100))
                    .padding(50)
                
                ZStack {
                    Text("📒")
                        .font(.system(size: 100))
                        .padding(50)
                    /*#-code-walkthrough(VHZ.2)*/
                }
            }
        }
    }
}


struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}
